import setuptools

setuptools.setup(
    name = "TwitterIsWasteOfTime",
    version = "1.0.3",
    license = 'GNU General Public License v3.0',
    author = "Carl Jellinek",
    author_email = "car1jellinek@gmail.com",
    description = "커뮤니티들을 크롤링합니다",
    # long_description = open('README.md').read(),
    long_description = open("README.md", "rt", encoding = "UTF8").read(),
    url = "https://github.com/FreelyReceivedFreelyGive/TwitterIsWasteOfTime.git",
    packages = setuptools.find_packages(),
    classifiers = [
        # 패키지에 대한 태그
        "Programming Language :: Python :: 3",
        # "License :: OSI Approved :: MIT License",
        'License :: OSI Approved :: GNU General Public License v3 or later (GPLv3+)',
        "Operating System :: OS Independent"
    ],
)