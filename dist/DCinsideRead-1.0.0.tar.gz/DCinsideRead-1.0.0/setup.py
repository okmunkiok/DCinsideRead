import setuptools

setuptools.setup(
    name = "DCinsideRead",
    version = "1.0.0",
    license = 'GNU General Public License v3.0',
    author = "Carl Jellinek",
    author_email = "car1jellinek@gmail.com",
    description = "디시인사이드를 비롯한 커뮤니티들을 크롤링합니다",
    # long_description = open('README.md').read(),
    long_description = open("README.md", "rt", encoding = "UTF8").read(),
    url = "https://github.com/FreelyReceivedFreelyGive/TwitterIsWasteOfTime.git",
    packages = setuptools.find_packages(),
    classifiers = [
        # 패키지에 대한 태그
        "Programming Language :: Python :: 3",
        # "License :: OSI Approved :: MIT License",
        'License :: OSI Approved :: GNU General Public License v3 or later (GPLv3+)',
        "Operating System :: OS Independent"
    ],
    keywords = ["디씨인사이드", "디시인사이드", "디시인사이드 갤러리", "디씨인사이드 갤러리",
    "DCinside", "dcinside", "DC", "dc", "gallery", "김유식", "유식", "횡령", "갤", "갤질", "개죽이"]
)